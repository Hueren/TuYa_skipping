import { combineReducers } from "../../../libs/redux";

export default combineReducers({
});